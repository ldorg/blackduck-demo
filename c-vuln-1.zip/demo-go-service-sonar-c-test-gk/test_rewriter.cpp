int main() {
	bool a = true;
	bool b = false;

	if( (a && b) || ( b && a)) {
	}
}
