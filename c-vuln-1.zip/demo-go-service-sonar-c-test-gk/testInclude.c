#include <stdio.h>
// This code is licensed under the New BSD license.
// See LICENSE.txt for more details.

int i = 4;
extern int j;

int main()
{
	printf("Hello World\n");
	return 0;
}
