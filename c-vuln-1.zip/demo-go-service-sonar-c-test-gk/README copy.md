# template-security-plugin

# Note
* This repo is use to test all the security plugins.
* For each security plugin seperate branch is used.
* The branch name refers to the name of the security plugin.
* Main branch is used for automation testing.
* Main branch will contain all workflows. 
 
